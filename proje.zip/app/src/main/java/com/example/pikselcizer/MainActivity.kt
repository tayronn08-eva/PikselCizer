package com.example.pikselcizer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val info = TextView(this).apply {
            textSize = 16f
            text = "1) Aşağıdaki düğmeyle Erişilebilirlik ayarlarını aç.\n" +
                "2) 'Piksel Çizer' servisini bul ve aç.\n" +
                "3) Ekranın kenarında yüzen bir ✎ simgesi belirecek.\n" +
                "4) Oyunu aç, çizim ekranına gir, simgeye bas ve testleri dene."
        }
        val btn = Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(info)
        root.addView(btn)
        setContentView(root)
    }
}
