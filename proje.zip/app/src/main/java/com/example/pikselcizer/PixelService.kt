package com.example.pikselcizer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

data class Step(val x1: Float, val y1: Float, val x2: Float = x1, val y2: Float = y1)

class PixelService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private var iconView: TextView? = null
    private var panelView: LinearLayout? = null
    private var calibView: TextView? = null
    private var status: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val modeNames = listOf("16x16", "32x32", "16x24")
    private val modeCols = listOf(16, 32, 16)
    private val modeRows = listOf(16, 32, 24)
    private var mode = 0
    private var running = false
    private var cancel = false

    private val prefs by lazy { getSharedPreferences("kalibrasyon", Context.MODE_PRIVATE) }
    private val keys = listOf("cx1", "cy1", "cx2", "cy2", "p0x", "p0y", "p27x", "p27y", "e0x", "e0y")

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showIcon()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { cancel = true }

    override fun onDestroy() {
        cancel = true
        iconView?.let { wm.removeView(it) }
        panelView?.let { wm.removeView(it) }
        calibView?.let { wm.removeView(it) }
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    // ---------- Arayüz ----------

    private fun showIcon() {
        val icon = TextView(this).apply {
            text = "✎"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(200, 30, 90, 200))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener {
                if (running) cancel = true else togglePanel()
            }
        }
        iconView = icon
        wm.addView(icon, overlayParams(0, dp(20)))
    }

    private fun setIcon(t: String) = handler.post { iconView?.text = t }
    private fun say(t: String) = handler.post { status?.text = t }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(6), dp(2), dp(6), dp(2))
        setOnClickListener { onClick() }
    }

    private fun closePanel() {
        panelView?.let { wm.removeView(it) }
        panelView = null
    }

    private fun togglePanel() {
        if (panelView != null) { closePanel(); return }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(230, 40, 40, 40))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            text = if (calibrated()) "Hazır (${modeNames[mode]})" else "Önce kalibre et"
        }
        val modeBtn = btn("Boyut: ${modeNames[mode]}") {}
        modeBtn.setOnClickListener {
            mode = (mode + 1) % modeNames.size
            modeBtn.text = "Boyut: ${modeNames[mode]}"
            say(if (calibrated()) "Hazır (${modeNames[mode]})" else "Önce kalibre et")
        }
        panel.addView(status)
        panel.addView(modeBtn)
        panel.addView(btn("Kalibre et") { startCalibration() })
        panel.addView(btn("Çizim testi") { startTestDraw() })
        panel.addView(btn("Test: 5 nokta") { testDots() })
        panel.addView(btn("Test: çizgi") { testLine() })
        panel.addView(btn("Kapat") { closePanel() })
        panelView = panel
        wm.addView(panel, overlayParams(dp(60), dp(20)))
    }

    // ---------- Kalibrasyon ----------

    private fun f(k: String) = prefs.getFloat("${modeNames[mode]}_$k", 0f)
    private fun calibrated() = prefs.contains("${modeNames[mode]}_e0y")

    private fun startCalibration() {
        closePanel()
        val prompts = listOf(
            "1/5: ÇİZİM ALANI sol-üst karenin ORTASINA dokun",
            "2/5: ÇİZİM ALANI sağ-alt karenin ORTASINA dokun",
            "3/5: PALETİN sol-üst karesine (gökkuşağı) dokun",
            "4/5: PALETİN 4. sıradaki en sağ karesine (damlalık) dokun",
            "5/5: PALETİN altındaki AYRI sıranın ilk (sol) karesine dokun"
        )
        val pts = ArrayList<Pair<Float, Float>>()
        var downTime = 0L
        val v = TextView(this).apply {
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            setTextColor(Color.YELLOW)
            textSize = 16f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            text = "[${modeNames[mode]}] ${prompts[0]}\n(1 sn basılı tutarsan iptal)"
        }
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> downTime = e.eventTime
                MotionEvent.ACTION_UP -> {
                    if (e.eventTime - downTime > 1000) {
                        endCalibration()
                    } else {
                        pts.add(Pair(e.rawX, e.rawY))
                        if (pts.size == prompts.size) {
                            val ed = prefs.edit()
                            for (i in pts.indices) {
                                ed.putFloat("${modeNames[mode]}_${keys[i * 2]}", pts[i].first)
                                ed.putFloat("${modeNames[mode]}_${keys[i * 2 + 1]}", pts[i].second)
                            }
                            ed.apply()
                            endCalibration()
                        } else {
                            v.text = "[${modeNames[mode]}] ${prompts[pts.size]}"
                        }
                    }
                }
            }
            true
        }
        calibView = v
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
    }

    private fun endCalibration() {
        calibView?.let { wm.removeView(it) }
        calibView = null
        setIcon(if (calibrated()) "✎ ✓" else "✎")
    }

    // ---------- Koordinat hesabı ----------

    private fun cell(col: Int, row: Int): Step {
        val cols = modeCols[mode]
        val rows = modeRows[mode]
        val x = f("cx1") + (f("cx2") - f("cx1")) * col / (cols - 1)
        val y = f("cy1") + (f("cy2") - f("cy1")) * row / (rows - 1)
        return Step(x, y)
    }

    // slot 0..27: üstteki 4x7 blok (0 = gökkuşağı, 27 = damlalık), 28..34: alttaki ayrı sıra
    private fun palette(slot: Int): Step {
        val dx = (f("p27x") - f("p0x")) / 6f
        val dy = (f("p27y") - f("p0y")) / 3f
        return if (slot < 28) {
            Step(f("p0x") + dx * (slot % 7), f("p0y") + dy * (slot / 7))
        } else {
            Step(f("e0x") + dx * (slot - 28), f("e0y"))
        }
    }

    // ---------- Dokunma motoru ----------

    private fun gesture(path: Path, durationMs: Long, done: (Boolean) -> Unit) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) = done(true)
            override fun onCancelled(d: GestureDescription?) = done(false)
        }, null)
        if (!ok) done(false)
    }

    // Adımları sırayla çalıştırır, hata olursa 2 kez tekrar dener.
    // Çalışırken panel kapanır; durdurmak için ✎ simgesine bas.
    private fun run(steps: List<Step>, gap: Long) {
        closePanel()
        running = true
        cancel = false

        fun finish(msg: String) {
            running = false
            setIcon("✎")
            say(msg)
        }

        fun next(i: Int, tries: Int) {
            if (cancel) { finish("Durduruldu: $i/${steps.size}"); return }
            if (i >= steps.size) { finish("Bitti: ${steps.size} adım"); return }
            setIcon("■ $i/${steps.size}")
            val s = steps[i]
            val isSwipe = s.x2 != s.x1 || s.y2 != s.y1
            val p = Path().apply {
                moveTo(s.x1, s.y1)
                if (isSwipe) lineTo(s.x2, s.y2)
            }
            gesture(p, if (isSwipe) 200L else 30L) { ok ->
                handler.postDelayed({
                    if (ok) next(i + 1, 0)
                    else if (tries < 2) next(i, tries + 1)
                    else finish("Hata: adım $i başarısız")
                }, gap)
            }
        }
        next(0, 0)
    }

    // ---------- Testler ----------

    private fun screenSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    private fun testDots() {
        val (w, h) = screenSize()
        run((0 until 5).map { Step(w * (0.45f + it * 0.04f), h / 2f) }, 120)
    }

    private fun testLine() {
        val (w, h) = screenSize()
        run(listOf(Step(w * 0.45f, h * 0.6f, w * 0.65f, h * 0.6f)), 0)
    }

    // Kırmızıyla bir çapraz, maviyle diğer çaprazı çizer
    private fun startTestDraw() {
        if (!calibrated()) { say("Önce kalibre et"); return }
        val cols = modeCols[mode]
        val rows = modeRows[mode]
        val n = minOf(cols, rows)
        val steps = ArrayList<Step>()
        steps.add(palette(3))      // kırmızı
        for (i in 0 until n) steps.add(cell(i, i))
        steps.add(palette(16))     // mavi
        for (i in 0 until n) steps.add(cell(cols - 1 - i, i))
        run(steps, 120)
    }
}
